WITH car AS (
 SELECT REPLACE(id_imovel,'-','') id_car_norm,area FROM `basedosdados.br_sfb_sicar.area_imovel`
 WHERE data_extracao>=DATE '2026-06-02' AND data_extracao<=DATE '2026-08-04'
 QUALIFY ROW_NUMBER() OVER(PARTITION BY REPLACE(id_imovel,'-','') ORDER BY data_extracao DESC)=1
),pl AS (SELECT DISTINCT id_referencia_bacen,numero_ordem,REPLACE(id_car,'-','') id_car_norm FROM `basedosdados.br_bcb_sicor.recurso_publico_propriedade` WHERE ano_emissao=2023 AND id_car IS NOT NULL AND TRIM(id_car)!=''),n AS (SELECT id_referencia_bacen,numero_ordem,COUNT(*) n_imoveis FROM pl GROUP BY 1,2),pc AS (
 SELECT c.id_car_norm,c.area,SUM(op.area_financiada/n.n_imoveis) area_financiada
 FROM `basedosdados.br_bcb_sicor.operacao` op JOIN n USING(id_referencia_bacen,numero_ordem) JOIN pl USING(id_referencia_bacen,numero_ordem) JOIN car c USING(id_car_norm) WHERE op.ano_emissao=2023 GROUP BY 1,2
),op_car AS (
 SELECT c.id_car_norm,op.id_referencia_bacen,op.numero_ordem,op.ano_safra_emissao,op.id_empreendimento,op.id_programa,op.id_fonte_recurso,op.valor_parcela_credito/n.n_imoveis credito,op.area_financiada/n.n_imoveis area_financiada,e.finalidade,e.produto
 FROM `basedosdados.br_bcb_sicor.operacao` op JOIN n USING(id_referencia_bacen,numero_ordem) JOIN pl USING(id_referencia_bacen,numero_ordem) JOIN pc c USING(id_car_norm) LEFT JOIN `basedosdados.br_bcb_sicor.empreendimento` e USING(id_empreendimento)
 WHERE op.ano_emissao=2023 AND c.area_financiada>c.area
),class AS (
 SELECT 'todas as safras' recorte,finalidade,COUNT(DISTINCT id_car_norm) imoveis,COUNT(DISTINCT id_referencia_bacen) operacoes,SUM(credito) credito,SUM(area_financiada) area_financiada FROM op_car GROUP BY finalidade
 UNION ALL
 SELECT CONCAT('Custeio — ',ano_safra_emissao),finalidade,COUNT(DISTINCT id_car_norm),COUNT(DISTINCT id_referencia_bacen),SUM(credito),SUM(area_financiada) FROM op_car WHERE finalidade='Custeio' GROUP BY ano_safra_emissao,finalidade
)
SELECT * FROM class ORDER BY recorte,credito DESC