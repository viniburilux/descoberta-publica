#!/usr/bin/env python3
"""Consulta da base PNCP deste pacote. Ex.: python consultar.py --uf BA --ano 2026 --municipio Salvador --csv saida.csv
--limite e um teto global de registros. Atencao: campos de texto podem conter quebras de linha,
entao o CSV resultante pode ter mais linhas fisicas que registros; conte registros, nao linhas."""
import argparse,csv,sys
from pathlib import Path
import duckdb
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--uf');p.add_argument('--ano',type=int);p.add_argument('--municipio');p.add_argument('--objeto');p.add_argument('--esfera',choices=['M','E','F','D','N']);p.add_argument('--limite',type=int,default=100);p.add_argument('--csv');p.add_argument('--resumo',action='store_true');p.add_argument('--sql',help='Consulta SELECT livre, banco em modo somente leitura');a=p.parse_args()
root=Path(__file__).parent
if (root/'consultas.duckdb').exists():
 c=duckdb.connect(str(root/'consultas.duckdb'),read_only=True)
else:
 parts=sorted((root/'compras_particionadas').glob('uf=*'))
 if not parts:raise SystemExit('Extraia ao menos um pacote UF na pasta da ferramenta. Use expandir.py.')
 if len(parts)<27:print(f'ATENCAO: consulta parcial, somente {len(parts)}/27 UFs extraidas.',file=sys.stderr)
 c=duckdb.connect()
 path=str(root/'compras_particionadas/**/*.parquet').replace("'","''")
 dim=str(root/'dim_municipios.parquet').replace("'","''")
 c.execute(f"CREATE VIEW compras AS SELECT * FROM read_parquet('{path}',hive_partitioning=true)")
 c.execute(f"CREATE VIEW dimensao AS SELECT * FROM read_parquet('{dim}')")
 c.execute("CREATE VIEW compras_contexto AS SELECT c.*,d.* EXCLUDE(cod_ibge),c.esfera='M' AS receita_municipal_comparavel,CASE WHEN c.esfera='M' AND d.rcl_2025>0 THEN c.valor_estimado/d.rcl_2025 ELSE NULL END AS estimado_sobre_rcl_2025,c.valor_estimado>1000000000 AS alerta_estimado_acima_1bi,CASE WHEN c.valor_homologado>0 THEN c.valor_estimado/c.valor_homologado>1000 ELSE false END AS alerta_estimado_1000x_homologado FROM compras c LEFT JOIN dimensao d USING(cod_ibge)")
where=[];vals=[]
for k,v in [('uf',a.uf.upper() if a.uf else None),('ano_publicacao',a.ano),('esfera',a.esfera)]:
 if v is not None:where.append(k+'=?');vals.append(v)
for k,v in [('municipio_pncp',a.municipio),('objeto',a.objeto)]:
 if v:where.append(k+' ILIKE ?');vals.append('%'+v+'%')
base=' FROM compras_contexto'+(' WHERE '+' AND '.join(where) if where else '')
q=a.sql or ('SELECT uf,ano_publicacao,esfera,count(*) registros'+base+' GROUP BY 1,2,3 ORDER BY 1,2,3' if a.resumo else 'SELECT numero_controle,uf,municipio_pncp,orgao,esfera,objeto,publicacao,valor_estimado,valor_homologado,pop_2025,pib_2023_mil_reais,rcl_2025,receitas_correntes_dca_2025,status_receita,alerta_estimado_acima_1bi,alerta_estimado_1000x_homologado,link_origem'+base+' ORDER BY publicacao DESC LIMIT '+str(max(1,a.limite)))
r=c.execute(q,[] if a.sql else vals);out=open(a.csv,'w',newline='',encoding='utf-8') if a.csv else sys.stdout;w=csv.writer(out);w.writerow([i[0] for i in r.description]);w.writerows(r.fetchall())
if a.csv:out.close()
