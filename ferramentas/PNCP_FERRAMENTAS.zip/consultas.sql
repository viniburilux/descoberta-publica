-- Mesmo banco logico, Brasil ou UF. Valores NAO sao gastos realizados.
SELECT uf, ano_publicacao, esfera, count(*) registros FROM compras GROUP BY 1,2,3;
SELECT * FROM compras_contexto WHERE uf='BA' AND ano_publicacao=2026 AND esfera='M' AND municipio_pncp ILIKE '%Salvador%' ORDER BY publicacao DESC LIMIT 100;
SELECT * FROM compras_contexto WHERE esfera='M' AND objeto ILIKE '%show%' AND NOT alerta_estimado_acima_1bi AND NOT alerta_estimado_1000x_homologado LIMIT 100;
-- Auditoria de ausencias. RCL e DCA sao colunas diferentes, sem COALESCE financeiro.
SELECT status_receita,count(*) FROM compras_contexto WHERE esfera='M' GROUP BY 1;
SELECT numero_controle,objeto,valor_estimado,valor_homologado,link_origem FROM compras_contexto WHERE alerta_estimado_acima_1bi OR alerta_estimado_1000x_homologado;
