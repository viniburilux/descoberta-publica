#!/usr/bin/env python3
"""Extrai os pacotes estaduais baixados na mesma pasta. Nao baixa nem modifica os originais."""
from pathlib import Path
import zipfile
root=Path(__file__).parent
zips=sorted(root.glob('PNCP_UF_*.zip'))
for p in zips:
 with zipfile.ZipFile(p) as z:
  for name in z.namelist():
   dest=(root/name).resolve()
   if not dest.is_relative_to(root.resolve()):raise ValueError('Caminho invalido no ZIP')
  z.extractall(root)
print(f'{len(zips)}/27 pacotes UF extraidos. Para consulta nacional baixe todos os27; para recorte local selecione os estados desejados.')
